﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Program3.Prog3
{
    public partial class Updating : System.Web.UI.Page
    {
        SqlDataAdapter da;
        DataSet ds;
        int index = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
 
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
            da = new SqlDataAdapter("Select * From Product", conn);
            ds = new DataSet();
            da.Fill(ds, "Product");
            if (index <= 0)
            {
                btnPrevious.Enabled = false;
                btnFirst.Enabled = false;
            }
            else
            {
                btnPrevious.Enabled = true;
                btnFirst.Enabled = true;
            }
            if (!IsPostBack)
            {
                index = (int)Session["Prog3_Index"];
                Getdata(index);
                if (index <= 0)
                {
                    btnPrevious.Enabled = false;
                    btnFirst.Enabled = false;
                }
                else
                {
                    btnPrevious.Enabled = true;
                    btnFirst.Enabled = true;
                }

            }

            
            

        }

        private void Getdata(int index)
        {
            String UnitPrice = "";
            txtId.Text = ds.Tables[0].Rows[index][0].ToString();
            txtName.Text = ds.Tables[0].Rows[index][1].ToString();
            UnitPrice = ds.Tables[0].Rows[index][2].ToString();
            txtPrice.Text = string.Format("{0:C}", Double.Parse(UnitPrice));
            txtDescription.Text = ds.Tables[0].Rows[index][3].ToString(); ;
        }


        protected void btnFirst_Click(object sender, EventArgs e)
        {
            int index = 0;
            btnNext.Enabled = true;
            btnLast.Enabled = true;
 
                btnPrevious.Enabled = false;
                btnFirst.Enabled = false;

            Session["Prog3_Index"] = index;
            Getdata(index);
            

        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            btnNext.Enabled = true;
            btnLast.Enabled = true;
           // btnFirst.Enabled = true;
            //btnPrevious.Enabled = true;
            int index = (int)Session["Prog3_Index"] - 1;
            if (index < 0)
                index = 0;
            btnPrevious.Enabled = true;
            if (index == 0)
            {
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
            }
            Session["Prog3_Index"] = index;
            Getdata(index);
            

        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            btnFirst.Enabled = true;
            btnPrevious.Enabled = true;
            int index = (int)Session["Prog3_Index"] + 1;
            if (index > ds.Tables[0].Rows.Count - 1)
                index = ds.Tables[0].Rows.Count - 1;
            Session["Prog3_Index"] = index;
                Getdata(index);
            if (index == ds.Tables[0].Rows.Count - 1)
            {
                btnNext.Enabled = false;
                btnLast.Enabled = false;
            }


        }

        protected void btnLast_Click(object sender, EventArgs e)
        {
            btnFirst.Enabled = true;
            btnPrevious.Enabled = true;
                btnNext.Enabled = false;
                btnLast.Enabled = false;
                index = ds.Tables[0].Rows.Count - 1;
            Session["Prog3_Index"] = index;
            Getdata(index);
            

        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            if (btnNew.Text == "New")
            {
                txtId.Text = "";
                txtName.Text = "";
                txtPrice.Text = "";
                txtDescription.Text = "";
                btnNew.Text = "Save New";
                btnDelete.Text = "Cancel";
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
                btnNext.Enabled = false;
                btnLast.Enabled = false;
                btnUpdate.Enabled = false;
            }
            else
            {
                try
                {
                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
                    conn.Open();
                    string insertQuery = "INSERT INTO Product(ProductID,ProductName,UnitPrice,Description) values (@UID,@Uname,@UPrice,@UDesc)";

                    SqlCommand com = new SqlCommand(insertQuery, conn);
                    com.Parameters.AddWithValue("@UID", txtId.Text);
                    com.Parameters.AddWithValue("@Uname", txtName.Text);
                    com.Parameters.AddWithValue("@UPrice", txtPrice.Text);
                    com.Parameters.AddWithValue("@UDesc", txtDescription.Text);
                    com.ExecuteNonQuery();
                    Response.Redirect("Updating.aspx");
                    txtMessage.Text = "Product Added!";
                    conn.Close();
                    btnNew.Text = "New";
                    btnDelete.Text = "Delete";
                    btnPrevious.Enabled = true;
                    btnFirst.Enabled = true;
                    btnNew.Enabled = true;
                    btnLast.Enabled = true;
                    btnUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    txtMessage.Text = "Error:" + ex.ToString();
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adapter = new SqlDataAdapter();
            if (txtId.Text == "P101" || txtId.Text == "P103" || txtId.Text == "P107" || txtId.Text == "P109" || txtId.Text == "P201" )
            {

            }
            else
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
                conn.Open();
                string checkuser = "select count(*) from Product where ProductId='" + txtId.Text + "'";
                SqlCommand com = new SqlCommand(checkuser, conn);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
                conn.Close();
                if (temp == 1)
                {
                    try
                    {
                        conn.Open();
                        string updateQuery = "Update Product set ProductName='" + txtName.Text + "',UnitPrice='" + txtPrice.Text 
                            +"', Description='" + txtDescription.Text + "' where ProductID='" + txtId.Text + "'";

                        com = new SqlCommand(updateQuery, conn);
                        adapter.UpdateCommand = new SqlCommand(updateQuery, conn);
                        adapter.UpdateCommand.ExecuteNonQuery();
                        Response.Redirect("Updating.aspx");
                        txtMessage.Text = "Product Updated!";
                        conn.Close();
                    }
                    catch (Exception ex)
                    {
                        txtMessage.Text = "Error:" + ex.ToString();
                    }
                }
                else
                {
                    txtMessage.Text = "ID does not exist!";
                }
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            btnFirst.Enabled = false;
            btnPrevious.Enabled = false;
            btnNext.Enabled = false;
            btnLast.Enabled = false;
            btnUpdate.Enabled = false;

            if (btnDelete.Text == "Cancel")
            {
                btnNew.Text = "New";
                btnDelete.Text = "Delete";
                btnPrevious.Enabled = true;
                btnFirst.Enabled = true;
                btnNew.Enabled = true;
                btnLast.Enabled = true;
                btnUpdate.Enabled = true;
            }
            else
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                if (txtId.Text == "P101" || txtId.Text == "P103" || txtId.Text == "P107" || txtId.Text == "P109" || txtId.Text == "P201")
                {
                    txtMessage.Text = "Cannot delete that Product.";
                }
                else
                {

                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
                    conn.Open();
                    string checkuser = "select count(*) from Product where ProductId='" + txtId.Text + "'";
                    SqlCommand com = new SqlCommand(checkuser, conn);
                    int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
                    conn.Close();
                    if (temp == 1)
                    {
                        try
                        {
                            conn.Open();
                            string DeleteQuery = "Delete Product where ProductId='" + txtId.Text + "'";

                            SqlCommand nameCom = new SqlCommand(DeleteQuery, conn);
                            adapter.DeleteCommand = new SqlCommand(DeleteQuery, conn);
                            adapter.DeleteCommand.ExecuteNonQuery();
                            
                            txtMessage.Text = "Product Deleted!";
                            conn.Close();
                            btnNew.Text = "New";
                            btnDelete.Text = "Delete";
                            btnPrevious.Enabled = true;
                            btnFirst.Enabled = true;
                            btnNew.Enabled = true;
                            btnLast.Enabled = true;
                            btnUpdate.Enabled = true;

                        }
                        catch (Exception ex)
                        {
                            txtMessage.Text = "Error:" + ex.ToString();
                        }
                    }
                    else
                    {
                        txtMessage.Text = "ID does not exist!";
                    }
                }
            }
        }
    }
}