﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

namespace Program3.Prog3
{
    public partial class Shopping : System.Web.UI.Page
    {
        double price;
        double quanity;
        double subTotal;
        double tax;
        double grandTotal;

        protected void Page_Load(object sender, EventArgs e)
        {
            txtID.Style["text-align"] = "right";
            txtName.Style["text-align"] = "right";
            txtPrice.Style["text-align"] = "right";
            txtQuantity.Style["text-align"] = "right";
            txtSubTotal.Style["text-align"] = "right";
            txtTax.Style["text-align"] = "right";
            txtGrandTotal.Style["text-align"] = "right";

            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void txtID_TextChanged(object sender, EventArgs e)
        {
            lblOutput.Text = "";
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count(*) from Product where ProductId='" + txtID.Text + "'";
            SqlCommand com = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            conn.Close();
            if (temp == 1)
            {
                conn.Open();
                string getName = "select ProductName from Product where ProductId='" + txtID.Text + "'";
                SqlCommand nameCom = new SqlCommand(getName, conn);
                String Name = nameCom.ExecuteScalar().ToString().Replace(" ", "");

                string getPrice = "select UnitPrice from Product where ProductId='" + txtID.Text + "'";
                SqlCommand priceCom = new SqlCommand(getPrice, conn);
                String price = priceCom.ExecuteScalar().ToString().Replace(" ", "");

                txtName.Text = Name;
                txtPrice.Text = string.Format("{0:C}", Decimal.Parse(price)); 
                txtQuantity.Focus();
            }
            else
            {
              //  Response.Write();
                lblOutput.Text = "User ID is not registered!";
                txtID.Text = "";
                txtName.Text = "";
                txtPrice.Text = "";
                txtQuantity.Text = "";
                txtSubTotal.Text = "";
                txtTax.Text = "";
                txtGrandTotal.Text = "";

                txtID.Focus();
            }

            conn.Close();
        }
    

        protected void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            lblOutput.Text = "";
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count(*) from Product where ProductId='" + txtID.Text + "'";
            SqlCommand com = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            conn.Close();
            if (temp == 1)
            {
                if (decimal.Parse(txtQuantity.Text) > 0)
                {
                    Taxamount();
                    txtSubTotal.Text = string.Format("{0:C}", subTotal);
                    txtTax.Text = string.Format("{0:C}", tax);
                    txtGrandTotal.Text = string.Format("{0:C}", grandTotal);
                }
                else
                {
                    txtSubTotal.Text = "";
                    txtTax.Text = "";
                    txtGrandTotal.Text = "";
                    txtQuantity.Focus();
                }
            }
            else
            {
                //  Response.Write();
                lblOutput.Text = "User ID is not registered!";
                
                txtQuantity.Focus();
            }


        }

        public void Taxamount()
        {
            price = Double.Parse(txtPrice.Text, NumberStyles.Currency);
            quanity = Double.Parse(txtQuantity.Text.Trim());
            subTotal = price * quanity;
            tax = subTotal * 0.055;
            grandTotal = subTotal + tax;

        }
    }
}