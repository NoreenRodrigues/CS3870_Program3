﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Program3.App_Code
{
    public class SQLDataClass
    {

    }
}